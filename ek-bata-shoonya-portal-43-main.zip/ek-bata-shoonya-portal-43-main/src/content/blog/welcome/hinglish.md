# Welcome to Ek Bata Shoonya!

*Published: 2025*

---

Hum Ek Bata Shoonya ka launch karte hue bahut excited hain — ek platform jahan maths ko simple aur accessible banaya jata hai.

## Hamara Mission

Hum maante hain ki maths sabke liye hai. Language ki barrier ko hataate hue, hum Hindi mein mathematical concepts ko present karte hain.

## Kya Available hai?

- **Courses**: Detailed lectures jo basic concepts se shuru hote hain
- **Notes**: PDF aur LaTeX format mein study material
- **Teen Language Modes**: Pure Hindi, Mixed, aur Roman (Hinglish)

## Aage ka Plan

Hum regularly nayi content add karte rahenge. Aapke suggestions ka swagat hai!

---

*— Ek Bata Shoonya Team*
