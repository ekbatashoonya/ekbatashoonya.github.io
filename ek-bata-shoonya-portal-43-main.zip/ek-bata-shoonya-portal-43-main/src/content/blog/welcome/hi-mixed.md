# Welcome to Ek Bata Shoonya!

*Published: 2025*

---

हम Ek Bata Shoonya का launch करते हुए बहुत excited हैं — एक platform जहाँ maths को simple और accessible बनाया जाता है।

## हमारा Mission

हम मानते हैं कि maths सबके लिए है। Language की barrier को हटाते हुए, हम Hindi में mathematical concepts को present करते हैं।

## क्या Available है?

- **Courses**: Detailed lectures जो basic concepts से शुरू होते हैं
- **Notes**: PDF और LaTeX format में study material
- **तीन Language Modes**: Pure Hindi, Mixed, और Roman (Hinglish)

## आगे का Plan

हम regularly नई content add करते रहेंगे। आपके suggestions का स्वागत है!

---

*— Ek Bata Shoonya Team*
